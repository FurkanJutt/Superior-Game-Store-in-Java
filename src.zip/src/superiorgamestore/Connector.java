package superiorgamestore;
import java.sql.*;

public class Connector 
{
    private Connection connector = null;
    
    public Connection connect()
    {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connector = DriverManager.getConnection("jdbc:sqlserver://localhost:1433; DATABASENAME=superiorGameStoreDB;", "furqan", "furqan");
            
            System.out.println("Connected to server...");
        } 
        catch (Exception ex) {
            System.err.println(ex);
        }
        return connector;
    }
}
