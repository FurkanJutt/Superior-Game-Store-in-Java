/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package superiorgamestore;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;

/**
 *
 * @author M.Samran & M. Furqan
 */
public class HomePage extends javax.swing.JFrame {

    /**
     * Creates new form HomePage
     */
    Connector Database = new Connector();
    public String userName;
    
    JLabel[] labels = new JLabel[6];
    JPanel[] panels = new JPanel[5];
    
    // default border for menu icons
    Border default_border = BorderFactory.createMatteBorder(0, 0, 0, 0, new Color(255,255,255));
    
    // purple border for menu icons
    Border purple_border = BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153,0,153));
    
    // page opened border
    Border select_border = BorderFactory.createMatteBorder(0, 1, 0, 0, new Color(153,0,153));
    
    // jframe border
    Border homeGameframe_border = BorderFactory.createMatteBorder(1, 1, 3, 2, new Color(153,0,153));
    
    public HomePage() {
        initComponents();
        
        labels[0] = lbl_homeIcon;
        labels[1] = lbl_storeIcon;
        labels[2] = lbl_libraryIcon;
        labels[3] = lbl_newsIcon;
        labels[4] = lbl_downloadIcon;
        labels[5] = lbl_accountIcon;
        
        
        panels[0] = panel_Home;
        panels[1] = panel_Store;
        panels[2] = panel_Library;
        panels[3] = panel_News;
        panels[4] = panel_user;
        //panels[5] = panel_UserOptions;
        
        //Main.setBorder(jframe_border);
        
        defaultPanel();
        addActionToMenuIcons();
        addActionToHomeGamePanels();
        addActionToUserPanel(new Color(153,0,153));
        addActionToLibraryGameContainer(homeGameframe_border);
        addActionToStoreGameContainer(homeGameframe_border);
        addActionToNewsPanel();
    }
    
    // load default panel
    private void defaultPanel(){
        showPanel(panel_Home);
        panel_Settings.setVisible(false);
        panel_Profile.setVisible(false);
        btn_nextMouseClicked(null);
        ImageIcon icon[] = new ImageIcon[5];
        icon[0] = new ImageIcon(getClass().getResource("/SliderImages/battlefield2042.jpg"));
        icon[1] = new ImageIcon(getClass().getResource("/SliderImages/gtav.jpg"));
        icon[2] = new ImageIcon(getClass().getResource("/SliderImages/need-for-speed-heat.jpg"));
        icon[3] = new ImageIcon(getClass().getResource("/SliderImages/ori-and-the-blind-forest.jpg"));
        icon[4] = new ImageIcon(getClass().getResource("/SliderImages/rdr2.jpg"));
        Image image[] = new Image[5];
        for(int i = 0;i<5;i++){
            image[i] =  icon[i].getImage().getScaledInstance(home_gamePanel1.getWidth(), home_gamePanel1.getHeight(), Image.SCALE_SMOOTH);
        }
        home_gamePanel1.setIcon(new ImageIcon(image[0]));
        home_gamePanel2.setIcon(new ImageIcon(image[1]));
        home_gamePanel3.setIcon(new ImageIcon(image[2]));
        home_gamePanel4.setIcon(new ImageIcon(image[3]));
        home_gamePanel5.setIcon(new ImageIcon(image[4]));
    }

    // function to show & hide Jpanels
    public void showPanel(JPanel panel)
    {
        for (JPanel panell : panels) {
            panell.setVisible(false);
            panel_Settings.setVisible(false);
            panel_Profile.setVisible(false);
        }
        panel.setVisible(true);
    }
    
//    public void setSelectedBorder(JLabel label)
//    {
//        for (JLabel label1 : labels) {
//            label1.setBorder(default_border);
//        }
//        label.setBorder(select_border);
//        lbl_pageTitle.setText("Superior Game Store: "+label.getToolTipText());
//    }
    
    // add action to menu icons
    public void addActionToMenuIcons()
    {
        Component[] components = panel_VerticalMenu.getComponents();
        
        for (Component component : components) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
//                        setSelectedBorder(label);
                        lbl_pageTitle.setText(label.getToolTipText());
                        
                        switch (label.getToolTipText()){
                            case "Home":
                                defaultPanel();
                                btn_nextMouseClicked(e);
                                break;
                            case "Store":
                                showPanel(panel_Store);
                                addImagesToStoreGames();
                                break;
                            case "Library":
                                showPanel(panel_Library);
                                addImagesToLibrary();
                                break;
                            case "News":
                                showPanel(panel_News);
                                break;
                            case "User":
                                panel_user.setVisible(true);
                                break;
                            default:
                                showPanel(panel_Home);
                                break;
                        }
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                       // label.setBackground(new Color(204,204,255));
                        label.setBorder(purple_border);
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                       // label.setBackground(new Color(255,255,255));
                       if(label.getBorder().equals(select_border))
                           label.setBorder(select_border);
                       else
                           label.setBorder(default_border);
                    }
                });
            }
        }
    }
    
    public void addActionToHomeGamePanels()
    {
        Component[] components = homeGamePanelContainer.getComponents();
        for(Component component: components)
        {
            if(component instanceof JLabel)
            {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        btn_nextMouseClicked(e);
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setBorder(homeGameframe_border);
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        label.setBorder(default_border);
                    }
                });
            }
        }
    }
    
    public void addActionToUserPanel(Color color)
    {
        Component[] components = panel_user.getComponents();
        for(Component component: components)
        {
            if(component instanceof JLabel)
            {
                JLabel label = (JLabel) component;
                label.setForeground(color);
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setForeground(Color.BLACK);
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        label.setForeground(color);
                    }
                });
            }
        }
    }
    
    public void addActionToLibraryGameContainer(Border border){
        Component[] components = library_allGamesContainer.getComponents();
        for(Component component: components)
        {
            if(component instanceof JLabel)
            {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setBorder(border);
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        label.setBorder(default_border);
                    }
                });
            }
        }
    }
    
    public void addActionToStoreGameContainer(Border border){
        Component[] components = store_gamesContainer.getComponents();
        for(Component component: components)
        {
            if(component instanceof JLabel)
            {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setBorder(border);
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        label.setBorder(default_border);
                    }
                });
            }
        }
    }
    
    private void addActionToNewsPanel(){
        Component[] components = jPanel1.getComponents();
        
        for (Component component : components) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setForeground(Head.getBackground());
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        label.setForeground(Color.BLACK);
                    }
                });
            }
        }
        
        Component[] components2 = jPanel2.getComponents();
        
        for (Component component : components2) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setForeground(Head.getBackground());
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        label.setForeground(Color.BLACK);
                    }
                });
            }
        }
        
        Component[] components3 = jPanel3.getComponents();
        
        for (Component component : components3) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setForeground(Head.getBackground());
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        label.setForeground(Color.BLACK);
                    }
                });
            }
        }
        
        Component[] components4 = jPanel4.getComponents();
        
        for (Component component : components4) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setForeground(Head.getBackground());
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        label.setForeground(Color.BLACK);
                    }
                });
            }
        }
    }
    
    private void SetSliderImage(ImageIcon img){
        sliderImage.setIcon(img);
    }
    // Image Slider Code
//    BufferedImage[] allimages; 
//    public void TakeImage(){
//        File file = new File(getClass().getResource("/Store").getFile());
//        //File file = new File(getClass().getClassLoader().getResource("/SliderImages").getFile());
//        File[] images = file.listFiles();
//        allimages = new BufferedImage[images.length];
//        for(int i = 0; i < images.length; i++)
//        {
//            try {
//                allimages[i] = ImageIO.read(images[i]);
//                ImageIcon icon = new ImageIcon(allimages[i]);
//                System.err.println(icon);
//            } catch (Exception e) {
//            }
//        }
//    }
//    
//    public void Show(int index){
//        String[] Images = TakeImage();
//        String img = Images[index];
//        ImageIcon icon = new ImageIcon(getClass().getResource("/SliderImages/"+img));
//        Image image =  icon.getImage().getScaledInstance(sliderImage.getWidth(), sliderImage.getHeight(), Image.SCALE_SMOOTH);
//        sliderImage.setIcon(new ImageIcon(image));
//    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Head = new javax.swing.JPanel();
        lbl_close = new javax.swing.JLabel();
        lbl_pageTitle = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lbl_minimize1 = new javax.swing.JLabel();
        Main = new javax.swing.JPanel();
        panel_Settings = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        panel_VerticalMenu = new javax.swing.JPanel();
        lbl_homeIcon = new javax.swing.JLabel();
        lbl_storeIcon = new javax.swing.JLabel();
        lbl_libraryIcon = new javax.swing.JLabel();
        lbl_newsIcon = new javax.swing.JLabel();
        lbl_accountIcon = new javax.swing.JLabel();
        lbl_downloadIcon = new javax.swing.JLabel();
        panel_Home = new javax.swing.JPanel();
        panel_imageSlider = new javax.swing.JPanel();
        sliderImage = new javax.swing.JLabel();
        btn_next = new javax.swing.JLabel();
        btn_previous = new javax.swing.JLabel();
        homeGamePanelContainer = new javax.swing.JPanel();
        home_gamePanel4 = new javax.swing.JLabel();
        home_gamePanel2 = new javax.swing.JLabel();
        home_gamePanel5 = new javax.swing.JLabel();
        home_gamePanel1 = new javax.swing.JLabel();
        home_gamePanel3 = new javax.swing.JLabel();
        panel_Store = new javax.swing.JPanel();
        store_gameOnSaleContainer = new javax.swing.JPanel();
        gameOnSale1 = new javax.swing.JLabel();
        gameOnSale2 = new javax.swing.JLabel();
        gameOnSale3 = new javax.swing.JLabel();
        gameOnSale4 = new javax.swing.JLabel();
        gameOnSale5 = new javax.swing.JLabel();
        gameOnSale6 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        store_gamesContainer = new javax.swing.JPanel();
        store_game1 = new javax.swing.JLabel();
        store_game2 = new javax.swing.JLabel();
        store_game3 = new javax.swing.JLabel();
        store_game4 = new javax.swing.JLabel();
        store_game5 = new javax.swing.JLabel();
        store_game6 = new javax.swing.JLabel();
        store_game7 = new javax.swing.JLabel();
        store_game8 = new javax.swing.JLabel();
        store_game9 = new javax.swing.JLabel();
        store_game10 = new javax.swing.JLabel();
        store_game11 = new javax.swing.JLabel();
        store_game12 = new javax.swing.JLabel();
        store_game13 = new javax.swing.JLabel();
        store_game14 = new javax.swing.JLabel();
        panel_Library = new javax.swing.JPanel();
        library_recentGamesContainer = new javax.swing.JPanel();
        recentGame1 = new javax.swing.JLabel();
        recentGame2 = new javax.swing.JLabel();
        recentGame3 = new javax.swing.JLabel();
        recentGame4 = new javax.swing.JLabel();
        recentGame5 = new javax.swing.JLabel();
        recentGame6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        library_allGamesContainer = new javax.swing.JPanel();
        library_game1 = new javax.swing.JLabel();
        library_game2 = new javax.swing.JLabel();
        library_game3 = new javax.swing.JLabel();
        library_game4 = new javax.swing.JLabel();
        library_game5 = new javax.swing.JLabel();
        library_game6 = new javax.swing.JLabel();
        library_game7 = new javax.swing.JLabel();
        library_game8 = new javax.swing.JLabel();
        library_game9 = new javax.swing.JLabel();
        library_game10 = new javax.swing.JLabel();
        library_game11 = new javax.swing.JLabel();
        library_game12 = new javax.swing.JLabel();
        library_game13 = new javax.swing.JLabel();
        library_game14 = new javax.swing.JLabel();
        panel_News = new javax.swing.JPanel();
        panel_latestNews = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        panel_oldNews = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        panel_user = new javax.swing.JPanel();
        user_profile = new javax.swing.JLabel();
        user_contact = new javax.swing.JLabel();
        user_logout = new javax.swing.JLabel();
        user_settings = new javax.swing.JLabel();
        panel_Profile = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txt_name = new javax.swing.JTextField();
        txt_email = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_userName = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_id = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_password = new javax.swing.JPasswordField();
        txt_confirmPassword = new javax.swing.JPasswordField();
        checkBox_showPassword = new javax.swing.JCheckBox();
        btn_edit = new javax.swing.JButton();
        btn_save = new javax.swing.JButton();
        lbl_emailValidation = new javax.swing.JLabel();
        lbl_conPassValidation = new javax.swing.JLabel();
        lbl_userValidation = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        Head.setBackground(new java.awt.Color(140, 37, 134));

        lbl_close.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/x-mark.png"))); // NOI18N
        lbl_close.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_closeMouseClicked(evt);
            }
        });

        lbl_pageTitle.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        lbl_pageTitle.setForeground(new java.awt.Color(248, 248, 248));
        lbl_pageTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_pageTitle.setText("Superior Game Store");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/superior-new-logo2.png"))); // NOI18N
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        lbl_minimize1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        lbl_minimize1.setForeground(new java.awt.Color(248, 248, 248));
        lbl_minimize1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_minimize1.setText("-");
        lbl_minimize1.setToolTipText("Minimize");
        lbl_minimize1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_minimize1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lbl_minimize1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_minimize1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_minimize1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_minimize1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout HeadLayout = new javax.swing.GroupLayout(Head);
        Head.setLayout(HeadLayout);
        HeadLayout.setHorizontalGroup(
            HeadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, HeadLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_pageTitle, javax.swing.GroupLayout.DEFAULT_SIZE, 1135, Short.MAX_VALUE)
                .addGap(76, 76, 76)
                .addComponent(lbl_minimize1, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_close)
                .addContainerGap())
        );
        HeadLayout.setVerticalGroup(
            HeadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, HeadLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(HeadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(HeadLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lbl_close, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_pageTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_minimize1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        Main.setBackground(new java.awt.Color(248, 248, 248));
        Main.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 2, 2, 2, new java.awt.Color(153, 0, 153)));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(140, 37, 134));
        jLabel1.setText("Change Color");

        jPanel5.setBackground(new java.awt.Color(255, 51, 255));
        jPanel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel5MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(0, 153, 0));
        jPanel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel6MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        jPanel7.setBackground(new java.awt.Color(153, 0, 153));
        jPanel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel7MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        jPanel8.setBackground(new java.awt.Color(255, 0, 51));
        jPanel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel8MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        jPanel9.setBackground(new java.awt.Color(255, 153, 0));
        jPanel9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel9MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        jPanel10.setBackground(new java.awt.Color(0, 102, 255));
        jPanel10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 297, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        jPanel11.setBackground(new java.awt.Color(255, 51, 102));
        jPanel11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel11MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panel_SettingsLayout = new javax.swing.GroupLayout(panel_Settings);
        panel_Settings.setLayout(panel_SettingsLayout);
        panel_SettingsLayout.setHorizontalGroup(
            panel_SettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_SettingsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_SettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panel_SettingsLayout.setVerticalGroup(
            panel_SettingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_SettingsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(140, Short.MAX_VALUE))
        );

        panel_SettingsLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jPanel10, jPanel11, jPanel5, jPanel6, jPanel9});

        panel_VerticalMenu.setBackground(new java.awt.Color(255, 255, 255));

        lbl_homeIcon.setBackground(new java.awt.Color(255, 255, 255));
        lbl_homeIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_homeIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/home-4-32 (0).png"))); // NOI18N
        lbl_homeIcon.setToolTipText("Home");
        lbl_homeIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_homeIcon.setOpaque(true);
        lbl_homeIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_homeIconMouseEntered(evt);
            }
        });

        lbl_storeIcon.setBackground(new java.awt.Color(255, 255, 255));
        lbl_storeIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_storeIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/store-32 (0).png"))); // NOI18N
        lbl_storeIcon.setToolTipText("Store");
        lbl_storeIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_storeIcon.setOpaque(true);
        lbl_storeIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_storeIconMouseClicked(evt);
            }
        });

        lbl_libraryIcon.setBackground(new java.awt.Color(255, 255, 255));
        lbl_libraryIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_libraryIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/filled-box-32 (0).png"))); // NOI18N
        lbl_libraryIcon.setToolTipText("Library");
        lbl_libraryIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_libraryIcon.setOpaque(true);

        lbl_newsIcon.setBackground(new java.awt.Color(255, 255, 255));
        lbl_newsIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_newsIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/newspaper-32 (0).png"))); // NOI18N
        lbl_newsIcon.setToolTipText("News");
        lbl_newsIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_newsIcon.setOpaque(true);

        lbl_accountIcon.setBackground(new java.awt.Color(255, 255, 255));
        lbl_accountIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_accountIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/manager-32 (0).png"))); // NOI18N
        lbl_accountIcon.setToolTipText("User");
        lbl_accountIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_accountIcon.setOpaque(true);

        lbl_downloadIcon.setBackground(new java.awt.Color(255, 255, 255));
        lbl_downloadIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_downloadIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/download-32 (0).png"))); // NOI18N
        lbl_downloadIcon.setToolTipText("Downloads");
        lbl_downloadIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lbl_downloadIcon.setOpaque(true);

        javax.swing.GroupLayout panel_VerticalMenuLayout = new javax.swing.GroupLayout(panel_VerticalMenu);
        panel_VerticalMenu.setLayout(panel_VerticalMenuLayout);
        panel_VerticalMenuLayout.setHorizontalGroup(
            panel_VerticalMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_VerticalMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_VerticalMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_homeIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_storeIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_libraryIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_newsIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_downloadIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_accountIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_VerticalMenuLayout.setVerticalGroup(
            panel_VerticalMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_VerticalMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_homeIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_storeIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_libraryIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_newsIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 335, Short.MAX_VALUE)
                .addComponent(lbl_downloadIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbl_accountIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel_Home.setBackground(new java.awt.Color(248, 248, 248));

        panel_imageSlider.setPreferredSize(new java.awt.Dimension(920, 400));

        sliderImage.setOpaque(true);
        sliderImage.setPreferredSize(new java.awt.Dimension(750, 400));

        btn_next.setBackground(new java.awt.Color(255, 255, 255));
        btn_next.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        btn_next.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/arrow-24-64.png"))); // NOI18N
        btn_next.setToolTipText("Next");
        btn_next.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_next.setOpaque(true);
        btn_next.setPreferredSize(new java.awt.Dimension(79, 14));
        btn_next.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_nextMouseClicked(evt);
            }
        });

        btn_previous.setBackground(new java.awt.Color(255, 255, 255));
        btn_previous.setIcon(new javax.swing.ImageIcon(getClass().getResource("/superiorgamestore/Images/arrow-88-64.png"))); // NOI18N
        btn_previous.setToolTipText("Previous");
        btn_previous.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_previous.setOpaque(true);
        btn_previous.setPreferredSize(new java.awt.Dimension(79, 14));
        btn_previous.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_previousMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panel_imageSliderLayout = new javax.swing.GroupLayout(panel_imageSlider);
        panel_imageSlider.setLayout(panel_imageSliderLayout);
        panel_imageSliderLayout.setHorizontalGroup(
            panel_imageSliderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_imageSliderLayout.createSequentialGroup()
                .addComponent(btn_previous, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sliderImage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_next, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel_imageSliderLayout.setVerticalGroup(
            panel_imageSliderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_imageSliderLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(panel_imageSliderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_previous, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_next, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(sliderImage, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        home_gamePanel4.setBackground(new java.awt.Color(204, 255, 255));
        home_gamePanel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        home_gamePanel4.setOpaque(true);

        home_gamePanel2.setBackground(new java.awt.Color(204, 255, 255));
        home_gamePanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        home_gamePanel2.setOpaque(true);

        home_gamePanel5.setBackground(new java.awt.Color(204, 255, 255));
        home_gamePanel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        home_gamePanel5.setOpaque(true);

        home_gamePanel1.setBackground(new java.awt.Color(204, 255, 255));
        home_gamePanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        home_gamePanel1.setOpaque(true);
        home_gamePanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                home_gamePanel1MouseClicked(evt);
            }
        });

        home_gamePanel3.setBackground(new java.awt.Color(204, 255, 255));
        home_gamePanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        home_gamePanel3.setOpaque(true);

        javax.swing.GroupLayout homeGamePanelContainerLayout = new javax.swing.GroupLayout(homeGamePanelContainer);
        homeGamePanelContainer.setLayout(homeGamePanelContainerLayout);
        homeGamePanelContainerLayout.setHorizontalGroup(
            homeGamePanelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homeGamePanelContainerLayout.createSequentialGroup()
                .addComponent(home_gamePanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(home_gamePanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(home_gamePanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(home_gamePanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(home_gamePanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        homeGamePanelContainerLayout.setVerticalGroup(
            homeGamePanelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(home_gamePanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
            .addComponent(home_gamePanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(home_gamePanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(home_gamePanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(home_gamePanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panel_HomeLayout = new javax.swing.GroupLayout(panel_Home);
        panel_Home.setLayout(panel_HomeLayout);
        panel_HomeLayout.setHorizontalGroup(
            panel_HomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_HomeLayout.createSequentialGroup()
                .addGap(161, 161, 161)
                .addGroup(panel_HomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(homeGamePanelContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_imageSlider, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(162, Short.MAX_VALUE))
        );
        panel_HomeLayout.setVerticalGroup(
            panel_HomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_HomeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel_imageSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(homeGamePanelContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panel_Store.setBackground(new java.awt.Color(248, 248, 248));

        store_gameOnSaleContainer.setBackground(new java.awt.Color(248, 248, 248));

        gameOnSale1.setBackground(new java.awt.Color(204, 255, 255));
        gameOnSale1.setOpaque(true);

        gameOnSale2.setBackground(new java.awt.Color(204, 255, 255));
        gameOnSale2.setOpaque(true);

        gameOnSale3.setBackground(new java.awt.Color(204, 255, 255));
        gameOnSale3.setOpaque(true);

        gameOnSale4.setBackground(new java.awt.Color(204, 255, 255));
        gameOnSale4.setOpaque(true);

        gameOnSale5.setBackground(new java.awt.Color(204, 255, 255));
        gameOnSale5.setOpaque(true);

        gameOnSale6.setBackground(new java.awt.Color(204, 255, 255));
        gameOnSale6.setOpaque(true);

        jButton7.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(140, 37, 134));
        jButton7.setText("Download");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton8.setForeground(new java.awt.Color(140, 37, 134));
        jButton8.setText("Download");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton9.setForeground(new java.awt.Color(140, 37, 134));
        jButton9.setText("Download");

        jButton10.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(140, 37, 134));
        jButton10.setText("Download");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton11.setForeground(new java.awt.Color(140, 37, 134));
        jButton11.setText("Download");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton12.setForeground(new java.awt.Color(140, 37, 134));
        jButton12.setText("Download");

        javax.swing.GroupLayout store_gameOnSaleContainerLayout = new javax.swing.GroupLayout(store_gameOnSaleContainer);
        store_gameOnSaleContainer.setLayout(store_gameOnSaleContainerLayout);
        store_gameOnSaleContainerLayout.setHorizontalGroup(
            store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(store_gameOnSaleContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(gameOnSale1, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE))
                .addGap(46, 46, 46)
                .addGroup(store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(gameOnSale2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(48, 48, 48)
                .addGroup(store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(gameOnSale3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(52, 52, 52)
                .addGroup(store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(gameOnSale4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(47, 47, 47)
                .addGroup(store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(gameOnSale5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(gameOnSale6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        store_gameOnSaleContainerLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {gameOnSale1, gameOnSale2, gameOnSale3, gameOnSale4, gameOnSale5, gameOnSale6});

        store_gameOnSaleContainerLayout.setVerticalGroup(
            store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(store_gameOnSaleContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(gameOnSale2, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                    .addComponent(gameOnSale1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gameOnSale3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(gameOnSale4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(gameOnSale5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(gameOnSale6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(store_gameOnSaleContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7)
                    .addComponent(jButton8)
                    .addComponent(jButton9)
                    .addComponent(jButton10)
                    .addComponent(jButton11)
                    .addComponent(jButton12))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        store_gameOnSaleContainerLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {gameOnSale1, gameOnSale2, gameOnSale3, gameOnSale4, gameOnSale5, gameOnSale6});

        store_gamesContainer.setBackground(new java.awt.Color(248, 248, 248));

        store_game1.setBackground(new java.awt.Color(204, 204, 255));
        store_game1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game1.setOpaque(true);
        store_game1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game1MouseClicked(evt);
            }
        });

        store_game2.setBackground(new java.awt.Color(204, 204, 255));
        store_game2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game2.setOpaque(true);
        store_game2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game2MouseClicked(evt);
            }
        });

        store_game3.setBackground(new java.awt.Color(204, 204, 255));
        store_game3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game3.setOpaque(true);
        store_game3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game3MouseClicked(evt);
            }
        });

        store_game4.setBackground(new java.awt.Color(204, 204, 255));
        store_game4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game4.setOpaque(true);
        store_game4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game4MouseClicked(evt);
            }
        });

        store_game5.setBackground(new java.awt.Color(204, 204, 255));
        store_game5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game5.setOpaque(true);
        store_game5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game5MouseClicked(evt);
            }
        });

        store_game6.setBackground(new java.awt.Color(204, 204, 255));
        store_game6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game6.setOpaque(true);
        store_game6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game6MouseClicked(evt);
            }
        });

        store_game7.setBackground(new java.awt.Color(204, 204, 255));
        store_game7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game7.setOpaque(true);
        store_game7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game7MouseClicked(evt);
            }
        });

        store_game8.setBackground(new java.awt.Color(204, 204, 255));
        store_game8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game8.setOpaque(true);
        store_game8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game8MouseClicked(evt);
            }
        });

        store_game9.setBackground(new java.awt.Color(204, 204, 255));
        store_game9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game9.setOpaque(true);
        store_game9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game9MouseClicked(evt);
            }
        });

        store_game10.setBackground(new java.awt.Color(204, 204, 255));
        store_game10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game10.setOpaque(true);
        store_game10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game10MouseClicked(evt);
            }
        });

        store_game11.setBackground(new java.awt.Color(204, 204, 255));
        store_game11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game11.setOpaque(true);
        store_game11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game11MouseClicked(evt);
            }
        });

        store_game12.setBackground(new java.awt.Color(204, 204, 255));
        store_game12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game12.setOpaque(true);
        store_game12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game12MouseClicked(evt);
            }
        });

        store_game13.setBackground(new java.awt.Color(204, 204, 255));
        store_game13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game13.setOpaque(true);
        store_game13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game13MouseClicked(evt);
            }
        });

        store_game14.setBackground(new java.awt.Color(204, 204, 255));
        store_game14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        store_game14.setOpaque(true);
        store_game14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                store_game14MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout store_gamesContainerLayout = new javax.swing.GroupLayout(store_gamesContainer);
        store_gamesContainer.setLayout(store_gamesContainerLayout);
        store_gamesContainerLayout.setHorizontalGroup(
            store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(store_gamesContainerLayout.createSequentialGroup()
                .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(store_game1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(store_game9, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(store_game6, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(store_game2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(store_game12, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(store_game7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(store_game11, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(store_game5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(store_game8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(store_game14, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(store_game13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(store_game3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(store_game10, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(store_game4, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        store_gamesContainerLayout.setVerticalGroup(
            store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(store_gamesContainerLayout.createSequentialGroup()
                .addComponent(store_game2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(store_game6, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(store_gamesContainerLayout.createSequentialGroup()
                .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(store_gamesContainerLayout.createSequentialGroup()
                        .addComponent(store_game1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(store_game9, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(store_gamesContainerLayout.createSequentialGroup()
                        .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(store_game12, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(store_game11, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(store_game8, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(store_game3, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(store_game10, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(store_gamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(store_game4, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(store_game13, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(store_game14, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(store_game5, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(store_game7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        store_gamesContainerLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {store_game1, store_game10, store_game11, store_game12, store_game13, store_game14, store_game2, store_game3, store_game4, store_game5, store_game6, store_game7, store_game8, store_game9});

        javax.swing.GroupLayout panel_StoreLayout = new javax.swing.GroupLayout(panel_Store);
        panel_Store.setLayout(panel_StoreLayout);
        panel_StoreLayout.setHorizontalGroup(
            panel_StoreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_StoreLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(store_gamesContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(store_gameOnSaleContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panel_StoreLayout.setVerticalGroup(
            panel_StoreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_StoreLayout.createSequentialGroup()
                .addComponent(store_gameOnSaleContainer, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(store_gamesContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panel_Library.setBackground(new java.awt.Color(248, 248, 248));

        library_recentGamesContainer.setBackground(new java.awt.Color(248, 248, 248));

        recentGame1.setBackground(new java.awt.Color(204, 255, 255));
        recentGame1.setOpaque(true);

        recentGame2.setBackground(new java.awt.Color(204, 255, 255));
        recentGame2.setOpaque(true);

        recentGame3.setBackground(new java.awt.Color(204, 255, 255));
        recentGame3.setOpaque(true);

        recentGame4.setBackground(new java.awt.Color(204, 255, 255));
        recentGame4.setOpaque(true);

        recentGame5.setBackground(new java.awt.Color(204, 255, 255));
        recentGame5.setOpaque(true);

        recentGame6.setBackground(new java.awt.Color(204, 255, 255));
        recentGame6.setOpaque(true);

        jButton1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(140, 37, 134));
        jButton1.setText("Play");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(140, 37, 134));
        jButton2.setText("Play");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(140, 37, 134));
        jButton3.setText("Play");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(140, 37, 134));
        jButton4.setText("Play");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(140, 37, 134));
        jButton5.setText("Play");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(140, 37, 134));
        jButton6.setText("Play");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout library_recentGamesContainerLayout = new javax.swing.GroupLayout(library_recentGamesContainer);
        library_recentGamesContainer.setLayout(library_recentGamesContainerLayout);
        library_recentGamesContainerLayout.setHorizontalGroup(
            library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(library_recentGamesContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(recentGame1, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(42, 42, 42)
                .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(recentGame2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(48, 48, 48)
                .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(recentGame3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(52, 52, 52)
                .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(recentGame4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(48, 48, 48)
                .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(recentGame5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(recentGame6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        library_recentGamesContainerLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {recentGame1, recentGame2, recentGame3, recentGame4, recentGame5, recentGame6});

        library_recentGamesContainerLayout.setVerticalGroup(
            library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(library_recentGamesContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(library_recentGamesContainerLayout.createSequentialGroup()
                        .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(recentGame2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(recentGame3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(recentGame4, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(recentGame6, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(recentGame5, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(library_recentGamesContainerLayout.createSequentialGroup()
                        .addComponent(recentGame1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(library_recentGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2)
                            .addComponent(jButton3)
                            .addComponent(jButton4)
                            .addComponent(jButton5)
                            .addComponent(jButton6))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        library_allGamesContainer.setBackground(new java.awt.Color(248, 248, 248));

        library_game1.setBackground(new java.awt.Color(204, 204, 255));
        library_game1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game1.setOpaque(true);
        library_game1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game1MouseClicked(evt);
            }
        });

        library_game2.setBackground(new java.awt.Color(204, 204, 255));
        library_game2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game2.setOpaque(true);
        library_game2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game2MouseClicked(evt);
            }
        });

        library_game3.setBackground(new java.awt.Color(204, 204, 255));
        library_game3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game3.setOpaque(true);
        library_game3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game3MouseClicked(evt);
            }
        });

        library_game4.setBackground(new java.awt.Color(204, 204, 255));
        library_game4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game4.setOpaque(true);
        library_game4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game4MouseClicked(evt);
            }
        });

        library_game5.setBackground(new java.awt.Color(204, 204, 255));
        library_game5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game5.setOpaque(true);
        library_game5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game5MouseClicked(evt);
            }
        });

        library_game6.setBackground(new java.awt.Color(204, 204, 255));
        library_game6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game6.setOpaque(true);
        library_game6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game6MouseClicked(evt);
            }
        });

        library_game7.setBackground(new java.awt.Color(204, 204, 255));
        library_game7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game7.setOpaque(true);
        library_game7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game7MouseClicked(evt);
            }
        });

        library_game8.setBackground(new java.awt.Color(204, 204, 255));
        library_game8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game8.setOpaque(true);
        library_game8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game8MouseClicked(evt);
            }
        });

        library_game9.setBackground(new java.awt.Color(204, 204, 255));
        library_game9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game9.setOpaque(true);
        library_game9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game9MouseClicked(evt);
            }
        });

        library_game10.setBackground(new java.awt.Color(204, 204, 255));
        library_game10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game10.setOpaque(true);
        library_game10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game10MouseClicked(evt);
            }
        });

        library_game11.setBackground(new java.awt.Color(204, 204, 255));
        library_game11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game11.setOpaque(true);
        library_game11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game11MouseClicked(evt);
            }
        });

        library_game12.setBackground(new java.awt.Color(204, 204, 255));
        library_game12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game12.setOpaque(true);
        library_game12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game12MouseClicked(evt);
            }
        });

        library_game13.setBackground(new java.awt.Color(204, 204, 255));
        library_game13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game13.setOpaque(true);
        library_game13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game13MouseClicked(evt);
            }
        });

        library_game14.setBackground(new java.awt.Color(204, 204, 255));
        library_game14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        library_game14.setOpaque(true);
        library_game14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_game14MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout library_allGamesContainerLayout = new javax.swing.GroupLayout(library_allGamesContainer);
        library_allGamesContainer.setLayout(library_allGamesContainerLayout);
        library_allGamesContainerLayout.setHorizontalGroup(
            library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(library_allGamesContainerLayout.createSequentialGroup()
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(library_game1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game9, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(library_game6, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(library_game12, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(library_game11, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(library_game8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game14, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(library_game13, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(library_game10, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game4, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        library_allGamesContainerLayout.setVerticalGroup(
            library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(library_allGamesContainerLayout.createSequentialGroup()
                .addComponent(library_game1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(library_game9, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(library_allGamesContainerLayout.createSequentialGroup()
                .addComponent(library_game2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(library_game6, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(library_allGamesContainerLayout.createSequentialGroup()
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(library_game12, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game11, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game8, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game3, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game10, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(library_allGamesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(library_game4, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game13, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game14, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game5, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(library_game7, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        library_allGamesContainerLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {library_game1, library_game10, library_game11, library_game12, library_game13, library_game14, library_game2, library_game3, library_game4, library_game5, library_game6, library_game7, library_game8, library_game9});

        javax.swing.GroupLayout panel_LibraryLayout = new javax.swing.GroupLayout(panel_Library);
        panel_Library.setLayout(panel_LibraryLayout);
        panel_LibraryLayout.setHorizontalGroup(
            panel_LibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_LibraryLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(library_allGamesContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(library_recentGamesContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panel_LibraryLayout.setVerticalGroup(
            panel_LibraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_LibraryLayout.createSequentialGroup()
                .addComponent(library_recentGamesContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(library_allGamesContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panel_News.setBackground(new java.awt.Color(248, 248, 248));

        panel_latestNews.setBackground(new java.awt.Color(248, 248, 248));
        panel_latestNews.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Latest News", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 3, 18), new java.awt.Color(153, 0, 153))); // NOI18N

        jLabel10.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("IGN");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Game Spot");
        jLabel12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("PC Gamer");
        jLabel13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(65, Short.MAX_VALUE))
        );

        jLabel15.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("Gamerant");
        jLabel15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("The Verge");
        jLabel16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Game informer");
        jLabel14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout panel_latestNewsLayout = new javax.swing.GroupLayout(panel_latestNews);
        panel_latestNews.setLayout(panel_latestNewsLayout);
        panel_latestNewsLayout.setHorizontalGroup(
            panel_latestNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panel_latestNewsLayout.setVerticalGroup(
            panel_latestNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_latestNewsLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel_oldNews.setBackground(new java.awt.Color(248, 248, 248));
        panel_oldNews.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Recent Weeks", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 3, 18), new java.awt.Color(153, 0, 153))); // NOI18N

        jLabel19.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("The Verge");
        jLabel19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("DenofGeek");
        jLabel17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("E3 Expo");
        jLabel18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel18MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(59, Short.MAX_VALUE))
        );

        jLabel21.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("Videogame Chronicle");
        jLabel21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("IGN");
        jLabel22.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("Tech crunch");
        jLabel20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, 556, Short.MAX_VALUE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout panel_oldNewsLayout = new javax.swing.GroupLayout(panel_oldNews);
        panel_oldNews.setLayout(panel_oldNewsLayout);
        panel_oldNewsLayout.setHorizontalGroup(
            panel_oldNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panel_oldNewsLayout.setVerticalGroup(
            panel_oldNewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_oldNewsLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panel_NewsLayout = new javax.swing.GroupLayout(panel_News);
        panel_News.setLayout(panel_NewsLayout);
        panel_NewsLayout.setHorizontalGroup(
            panel_NewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_NewsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel_latestNews, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panel_oldNews, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        panel_NewsLayout.setVerticalGroup(
            panel_NewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_NewsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_NewsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panel_latestNews, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel_oldNews, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        panel_user.setBackground(new java.awt.Color(248, 248, 248));
        panel_user.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(153, 0, 153)));
        panel_user.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panel_userMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panel_userMouseExited(evt);
            }
        });

        user_profile.setFont(new java.awt.Font("Segoe UI", 3, 15)); // NOI18N
        user_profile.setForeground(new java.awt.Color(153, 0, 153));
        user_profile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        user_profile.setText("Profile");
        user_profile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        user_profile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                user_profileMouseClicked(evt);
            }
        });

        user_contact.setFont(new java.awt.Font("Segoe UI", 3, 15)); // NOI18N
        user_contact.setForeground(new java.awt.Color(153, 0, 153));
        user_contact.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        user_contact.setText("Contact");
        user_contact.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        user_contact.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                user_contactMouseClicked(evt);
            }
        });

        user_logout.setFont(new java.awt.Font("Segoe UI", 3, 15)); // NOI18N
        user_logout.setForeground(new java.awt.Color(153, 0, 153));
        user_logout.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        user_logout.setText("Logout");
        user_logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        user_logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                user_logoutMouseClicked(evt);
            }
        });

        user_settings.setFont(new java.awt.Font("Segoe UI", 3, 15)); // NOI18N
        user_settings.setForeground(new java.awt.Color(153, 0, 153));
        user_settings.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        user_settings.setText("Settings");
        user_settings.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        user_settings.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                user_settingsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panel_userLayout = new javax.swing.GroupLayout(panel_user);
        panel_user.setLayout(panel_userLayout);
        panel_userLayout.setHorizontalGroup(
            panel_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_userLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(user_profile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(user_contact, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(user_logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(user_settings, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE))
                .addContainerGap())
        );
        panel_userLayout.setVerticalGroup(
            panel_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_userLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(user_profile)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(user_contact)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(user_settings)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(user_logout)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel3.setText("Name: ");

        txt_name.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txt_name.setEnabled(false);

        txt_email.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txt_email.setEnabled(false);
        txt_email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_emailFocusLost(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel4.setText("Email: ");

        txt_userName.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txt_userName.setEnabled(false);
        txt_userName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_userNameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_userNameFocusLost(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel5.setText("Username: ");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel6.setText("Password: ");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel7.setText("Confirm Password: ");

        txt_id.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txt_id.setEnabled(false);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel8.setText("ID: ");

        txt_password.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txt_password.setEnabled(false);
        txt_password.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_passwordFocusLost(evt);
            }
        });

        txt_confirmPassword.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txt_confirmPassword.setEnabled(false);
        txt_confirmPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_confirmPasswordFocusLost(evt);
            }
        });

        checkBox_showPassword.setText("Show Password");
        checkBox_showPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkBox_showPasswordActionPerformed(evt);
            }
        });

        btn_edit.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        btn_edit.setText("Edit");
        btn_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_editActionPerformed(evt);
            }
        });

        btn_save.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        btn_save.setText("Save");
        btn_save.setEnabled(false);
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel_ProfileLayout = new javax.swing.GroupLayout(panel_Profile);
        panel_Profile.setLayout(panel_ProfileLayout);
        panel_ProfileLayout.setHorizontalGroup(
            panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_ProfileLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addGroup(panel_ProfileLayout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txt_name)
                                .addComponent(txt_email, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE))
                            .addComponent(lbl_userValidation)
                            .addComponent(lbl_emailValidation)))
                    .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(checkBox_showPassword)
                        .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(panel_ProfileLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(122, 122, 122)
                                .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panel_ProfileLayout.createSequentialGroup()
                                .addComponent(btn_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_ProfileLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txt_password, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panel_ProfileLayout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbl_conPassValidation)
                                    .addComponent(txt_confirmPassword)))))
                    .addGroup(panel_ProfileLayout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(72, 72, 72)
                        .addComponent(txt_userName)))
                .addContainerGap(838, Short.MAX_VALUE))
        );
        panel_ProfileLayout.setVerticalGroup(
            panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_ProfileLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_emailValidation)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_userName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(lbl_userValidation)
                .addGap(7, 7, 7)
                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txt_password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(checkBox_showPassword)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txt_confirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_conPassValidation)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(panel_ProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_edit, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_save, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(317, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout MainLayout = new javax.swing.GroupLayout(Main);
        Main.setLayout(MainLayout);
        MainLayout.setHorizontalGroup(
            MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainLayout.createSequentialGroup()
                .addComponent(panel_VerticalMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel_Home, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainLayout.createSequentialGroup()
                    .addContainerGap(67, Short.MAX_VALUE)
                    .addComponent(panel_Store, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainLayout.createSequentialGroup()
                    .addContainerGap(68, Short.MAX_VALUE)
                    .addComponent(panel_Library, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainLayout.createSequentialGroup()
                    .addContainerGap(67, Short.MAX_VALUE)
                    .addComponent(panel_News, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainLayout.createSequentialGroup()
                    .addContainerGap(69, Short.MAX_VALUE)
                    .addComponent(panel_user, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(1140, 1140, 1140)))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(MainLayout.createSequentialGroup()
                    .addGap(68, 68, 68)
                    .addComponent(panel_Settings, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(934, Short.MAX_VALUE)))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainLayout.createSequentialGroup()
                    .addContainerGap(66, Short.MAX_VALUE)
                    .addComponent(panel_Profile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );
        MainLayout.setVerticalGroup(
            MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_VerticalMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(MainLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel_Home, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(MainLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panel_Store, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(MainLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panel_Library, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(MainLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panel_News, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MainLayout.createSequentialGroup()
                    .addContainerGap(532, Short.MAX_VALUE)
                    .addComponent(panel_user, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(MainLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panel_Settings, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(MainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(MainLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panel_Profile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Head, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Main, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Head, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(Main, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lbl_closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_closeMouseClicked
        // TODO add your handling code here:
        int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
        if (response == JOptionPane.NO_OPTION) {
          System.out.println("No button clicked");
        } else if (response == JOptionPane.YES_OPTION) {
          System.out.println("Program Ended");
          this.dispose();
        } else if (response == JOptionPane.CLOSED_OPTION) {
          System.out.println("JOptionPane closed");
        }
        
    }//GEN-LAST:event_lbl_closeMouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        Color darkMode = new Color(46, 49, 49);
        Color lightMode = new Color(248, 248, 248);
        if(!Main.getBackground().equals(darkMode))
        {
            Main.setBackground(darkMode);
        }
        else
        {
            Main.setBackground(lightMode);
        }
    }//GEN-LAST:event_jLabel2MouseClicked

    private void lbl_storeIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_storeIconMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_lbl_storeIconMouseClicked

    private void lbl_homeIconMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_homeIconMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_lbl_homeIconMouseEntered
    
    int position = 0;
    
    private void btn_nextMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_nextMouseClicked
        // TODO add your handling code here:
        ImageIcon icon[] = new ImageIcon[6];
        icon[0] = new ImageIcon(getClass().getResource("/SliderImages/GOW.jpg"));
        icon[1] = new ImageIcon(getClass().getResource("/SliderImages/battlefield2042.jpg"));
        icon[2] = new ImageIcon(getClass().getResource("/SliderImages/gtav.jpg"));
        icon[3] = new ImageIcon(getClass().getResource("/SliderImages/need-for-speed-heat.jpg"));
        icon[4] = new ImageIcon(getClass().getResource("/SliderImages/ori-and-the-blind-forest.jpg"));
        icon[5] = new ImageIcon(getClass().getResource("/SliderImages/rdr2.jpg"));
        
        if(position<=5){
            Image image =  icon[position].getImage().getScaledInstance(sliderImage.getWidth(), sliderImage.getHeight(), Image.SCALE_SMOOTH);
            SetSliderImage(new ImageIcon(image));
            System.out.println("SliderImage: " + position);
            position++;
        }
        else{
            position=0;
        }
//        new Thread();
//        try {
//            Thread.sleep(300);
//        } catch (InterruptedException ex) {
//            Logger.getLogger(HomePage.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        int p = this.sliderImage.getX();
//        
//        if(p>-1){
//            Animacion.Animacion.mover_izquierda(750, 400, 1, 2, sliderImage);
//        }
//        position = position+1;
//        if(position >= TakeImage().length){
//            position = TakeImage().length-1;
//        }
//        Show(position);
    }//GEN-LAST:event_btn_nextMouseClicked

    private String storeImage(int index){
        String image = "supermariomaker2";
         try {
                Connection con = Database.connect();
                Statement statement = con.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT gameImage FROM StoreGames WHERE gameIndex = '"+index+"'");
                while(resultSet.next())
                {
                    image = resultSet.getString("gameImage");
                }
                con.close();
                return image;
            } 
            catch (Exception e)
            {
                System.err.println(e);
                return image;
            }
    }
    
    public void addImagesToStoreGames()
    {
        ImageIcon icon[] = new ImageIcon[6];
        icon[0] = new ImageIcon(getClass().getResource("/Store/220px-Battlefield_1_cover_art.jpg"));
        icon[1] = new ImageIcon(getClass().getResource("/Store/Spec_Ops_The_Line_cover.png"));
        icon[2] = new ImageIcon(getClass().getResource("/Store/ascent.png"));
        icon[3] = new ImageIcon(getClass().getResource("/Store/battlefield5.jpg"));
        icon[4] = new ImageIcon(getClass().getResource("/Store/borderland.jpg"));
        icon[5] = new ImageIcon(getClass().getResource("/Store/titanfall2.jpeg"));
        Image image[] = new Image[6];
        for(int i = 0;i<6;i++){
            image[i] =  icon[i].getImage().getScaledInstance(gameOnSale1.getWidth(), gameOnSale1.getHeight(), Image.SCALE_SMOOTH);
        }
        gameOnSale1.setIcon(new ImageIcon(image[0]));
        gameOnSale2.setIcon(new ImageIcon(image[1]));
        gameOnSale3.setIcon(new ImageIcon(image[2]));
        gameOnSale4.setIcon(new ImageIcon(image[3]));
        gameOnSale5.setIcon(new ImageIcon(image[4]));
        gameOnSale6.setIcon(new ImageIcon(image[5]));
        
        ImageIcon icon2[] = new ImageIcon[14];
        icon2[0] = new ImageIcon(getClass().getResource("/Store/"+storeImage(1)+""));
        icon2[1] = new ImageIcon(getClass().getResource("/Store/"+storeImage(2)+""));
        icon2[2] = new ImageIcon(getClass().getResource("/Store/"+storeImage(3)+""));
        icon2[3] = new ImageIcon(getClass().getResource("/Store/"+storeImage(4)+""));
        icon2[4] = new ImageIcon(getClass().getResource("/Store/"+storeImage(5)+""));
        icon2[5] = new ImageIcon(getClass().getResource("/Store/"+storeImage(6)+""));
        icon2[6] = new ImageIcon(getClass().getResource("/Store/"+storeImage(7)+""));
        icon2[7] = new ImageIcon(getClass().getResource("/Store/"+storeImage(8)+""));
        icon2[8] = new ImageIcon(getClass().getResource("/Store/"+storeImage(9)+""));
        icon2[9] = new ImageIcon(getClass().getResource("/Store/"+storeImage(10)+""));
        icon2[10] = new ImageIcon(getClass().getResource("/Store/"+storeImage(11)+""));
        icon2[11] = new ImageIcon(getClass().getResource("/Store/"+storeImage(12)+""));
        icon2[12] = new ImageIcon(getClass().getResource("/Store/"+storeImage(13)+""));
        icon2[13] = new ImageIcon(getClass().getResource("/Store/"+storeImage(14)+""));
        //icon2[14] = new ImageIcon(getClass().getResource("/Store/tombraider.jpg"));
        Image image2[] = new Image[14];
        for(int i = 0;i<14;i++){
            image2[i] =  icon2[i].getImage().getScaledInstance(store_game1.getWidth(), store_game1.getHeight(), Image.SCALE_SMOOTH);
        }
        store_game1.setIcon(new ImageIcon(image2[0]));
        store_game2.setIcon(new ImageIcon(image2[1]));
        store_game3.setIcon(new ImageIcon(image2[2]));
        store_game4.setIcon(new ImageIcon(image2[3]));
        store_game5.setIcon(new ImageIcon(image2[4]));
        store_game6.setIcon(new ImageIcon(image2[5]));
        store_game7.setIcon(new ImageIcon(image2[6]));
        store_game8.setIcon(new ImageIcon(image2[7]));
        store_game9.setIcon(new ImageIcon(image2[8]));
        store_game10.setIcon(new ImageIcon(image2[9]));
        store_game11.setIcon(new ImageIcon(image2[10]));
        store_game12.setIcon(new ImageIcon(image2[13]));
        store_game13.setIcon(new ImageIcon(image2[12]));
        store_game14.setIcon(new ImageIcon(image2[11]));
    }
    
    private String libraryImage(int index){
        String image = "supermariomaker2";
         try {
                Connection con = Database.connect();
                Statement statement = con.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT gameImage FROM LibraryGames WHERE gameIndex = '"+index+"'");
                while(resultSet.next())
                {
                    image = resultSet.getString("gameImage");
                }
                con.close();
                return image;
            } 
            catch (Exception e)
            {
                System.err.println(e);
                return image;
            }
    }
    
    public void addImagesToLibrary()
    {
        ImageIcon icon[] = new ImageIcon[6];
        icon[0] = new ImageIcon(getClass().getResource("/Library/cuphead.jpg"));
        icon[1] = new ImageIcon(getClass().getResource("/Library/deadrising3.jpg"));
        icon[2] = new ImageIcon(getClass().getResource("/Library/fist.jpg"));
        icon[3] = new ImageIcon(getClass().getResource("/Library/doom.jpg"));
        icon[4] = new ImageIcon(getClass().getResource("/Library/farcry3.jpg"));
        icon[5] = new ImageIcon(getClass().getResource("/Library/farcry4.jpg"));
        Image image[] = new Image[6];
        for(int i = 0;i<6;i++){
            image[i] =  icon[i].getImage().getScaledInstance(gameOnSale1.getWidth(), gameOnSale1.getHeight(), Image.SCALE_SMOOTH);
        }
        recentGame1.setIcon(new ImageIcon(image[0]));
        recentGame2.setIcon(new ImageIcon(image[1]));
        recentGame3.setIcon(new ImageIcon(image[2]));
        recentGame4.setIcon(new ImageIcon(image[3]));
        recentGame5.setIcon(new ImageIcon(image[4]));
        recentGame6.setIcon(new ImageIcon(image[5]));
        
        ImageIcon icon2[] = new ImageIcon[14];
        icon2[0] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(1)+""));
        icon2[1] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(2)+""));
        icon2[2] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(3)+""));
        icon2[3] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(4)+""));
        icon2[4] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(5)+""));
        icon2[5] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(6)+""));
        icon2[6] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(7)+""));
        icon2[7] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(8)+""));
        icon2[8] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(9)+""));
        icon2[9] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(10)+""));
        icon2[10] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(11)+""));
        icon2[11] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(12)+""));
        icon2[12] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(13)+""));
        icon2[13] = new ImageIcon(getClass().getResource("/Library/"+libraryImage(14)+""));
        //icon2[14] = new ImageIcon(getClass().getResource("/Store/tombraider.jpg"));
        Image image2[] = new Image[14];
        for(int i = 0;i<14;i++){
            image2[i] =  icon2[i].getImage().getScaledInstance(store_game1.getWidth(), store_game1.getHeight(), Image.SCALE_SMOOTH);
        }
        library_game1.setIcon(new ImageIcon(image2[0]));
        library_game2.setIcon(new ImageIcon(image2[1]));
        library_game3.setIcon(new ImageIcon(image2[2]));
        library_game4.setIcon(new ImageIcon(image2[3]));
        library_game5.setIcon(new ImageIcon(image2[4]));
        library_game6.setIcon(new ImageIcon(image2[5]));
        library_game7.setIcon(new ImageIcon(image2[6]));
        library_game8.setIcon(new ImageIcon(image2[7]));
        library_game9.setIcon(new ImageIcon(image2[8]));
        library_game10.setIcon(new ImageIcon(image2[9]));
        library_game11.setIcon(new ImageIcon(image2[10]));
        library_game12.setIcon(new ImageIcon(image2[11]));
        library_game13.setIcon(new ImageIcon(image2[12]));
        library_game14.setIcon(new ImageIcon(image2[13]));
    }
    
    private void btn_previousMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_previousMouseClicked
        // TODO add your handling code here:
        ImageIcon icon[] = new ImageIcon[6];
        icon[0] = new ImageIcon(getClass().getResource("/SliderImages/GOW.jpg"));
        icon[1] = new ImageIcon(getClass().getResource("/SliderImages/battlefield2042.jpg"));
        icon[2] = new ImageIcon(getClass().getResource("/SliderImages/gtav.jpg"));
        icon[3] = new ImageIcon(getClass().getResource("/SliderImages/need-for-speed-heat.jpg"));
        icon[4] = new ImageIcon(getClass().getResource("/SliderImages/ori-and-the-blind-forest.jpg"));
        icon[5] = new ImageIcon(getClass().getResource("/SliderImages/rdr2.jpg"));
        
        if(position>=0){
            Image image =  icon[position].getImage().getScaledInstance(sliderImage.getWidth(), sliderImage.getHeight(), Image.SCALE_SMOOTH);
            SetSliderImage(new ImageIcon(image));
            System.out.println("SliderImage: " + position);
            position--;
        }
        else{
            position=5;
        }
    }//GEN-LAST:event_btn_previousMouseClicked

    private void panel_userMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel_userMouseExited
        // TODO add your handling code here:
        //panel_user.setVisible(false);
    }//GEN-LAST:event_panel_userMouseExited

    private void panel_userMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel_userMouseEntered
        // TODO add your handling code here:
        panel_user.setBackground(new Color(245, 245, 245));
    }//GEN-LAST:event_panel_userMouseEntered

    private void home_gamePanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_home_gamePanel1MouseClicked
        // TODO add your handling code here:
       // TakeImage();
        //System.out.println(image[0]);
    }//GEN-LAST:event_home_gamePanel1MouseClicked

    private void DownloadGame(int index){
        try {
                Connection con = Database.connect();
                Statement statement = con.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT gameLink FROM StoreGames WHERE gameIndex = '"+index+"'");
                while(resultSet.next())
                {
                    String url = resultSet.getString("gameLink");
                    int response = JOptionPane.showConfirmDialog(null, "Open browser to download the game?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
                    if (response == JOptionPane.NO_OPTION) {
                      System.out.println("Cancled download");
                    } else if (response == JOptionPane.YES_OPTION) {
                      System.out.println("Opening Browser");
                      Desktop browser = Desktop.getDesktop();
                        try {
                            browser.browse(new URI(url));
                        } catch (Exception e) {
                            System.out.println("error : " + e);
                        }
                    } else if (response == JOptionPane.CLOSED_OPTION) {
                      System.out.println("JOptionPane closed");
                    }
                }
                con.close();
            } 
            catch (Exception e)
            {
                System.err.println(e);
            }
        
    }
    
    private void runGame(int index){
        try {
            Connection con = Database.connect();
            Statement statement = con.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT gameLink FROM LibraryGames WHERE gameIndex = '"+index+"'");
            while(resultSet.next())
            {
                String gamePath = resultSet.getString("gameLink");
                try {
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + gamePath);
                System.out.println("game running");
                } catch (IOException e) {
                    System.err.println("Game run exception: "+e);
                }
            }
            con.close();
        } catch (Exception e) {
            System.err.println("Game run exception: "+e);
        }
}
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
//        String response = JOptionPane.showInputDialog("Enter game path");
//        if (response.equals("")) {
//          System.out.println("No path selected");
//        } else {
            try {
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + "I:\\cuphead\\Cuphead.exe");
                System.out.println("game running");
            } catch (IOException e) {
                System.err.println("Game run exception: "+e);
            }
//        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        try {
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + "I:\\deadrising\\deadrising3.exe");
                System.out.println("game running");
            } catch (IOException e) {
                System.err.println("Game run exception: "+e);
            }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try {
            Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + "I:\\F.I.S.T. - Forged In Shadow Torch\\ZingangGame.exe");
        } catch (IOException e) {
            System.err.println("invalid username\nexception: "+e);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        try {
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + "I:\\doom\\doom.exe");
                System.out.println("game running");
            } catch (IOException e) {
                System.err.println("Game run exception: "+e);
            }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        try {
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + "I:\\farcry3\\Farcry3.exe");
                System.out.println("game running");
            } catch (IOException e) {
                System.err.println("Game run exception: "+e);
            }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        try {
                Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + "I:\\farcry4\\Farcry4.exe");
                System.out.println("game running");
            } catch (IOException e) {
                System.err.println("Game run exception: "+e);
            }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        int response = JOptionPane.showConfirmDialog(null, "Open browser to download the game?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
        if (response == JOptionPane.NO_OPTION) {
          System.out.println("Cancled download");
        } else if (response == JOptionPane.YES_OPTION) {
          System.out.println("Opening Browser");
          Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("http://5.9.71.125/ipcgames.com/download.php?url_str=https%3A%2F%2F5.9.71.125%2FiGetintopc.com%2Fdownload.php%3Ffilename%3Dipcgames.com_Battlefield_1.zip%26expires%3D1639341230%26signature%3D39cfb543bcd087d9dd91957242bcd749&filename=ipcgames.com_Battlefield_1.zip"));
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
        } else if (response == JOptionPane.CLOSED_OPTION) {
          System.out.println("JOptionPane closed");
        }
        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void user_logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_logoutMouseClicked
        // TODO add your handling code here:
        int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
        if (response == JOptionPane.NO_OPTION) {
          System.out.println("No button clicked");
        } else if (response == JOptionPane.YES_OPTION) {
          System.out.println("Back to login");
          this.dispose();
          Login login = new Login();
          login.setVisible(true);
        } else if (response == JOptionPane.CLOSED_OPTION) {
          System.out.println("JOptionPane closed");
        }
    }//GEN-LAST:event_user_logoutMouseClicked

    private void library_game1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game1MouseClicked
        // TODO add your handling code here:
        runGame(1);
    }//GEN-LAST:event_library_game1MouseClicked

    private void library_game2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game2MouseClicked
        // TODO add your handling code here:
        runGame(2);
    }//GEN-LAST:event_library_game2MouseClicked

    private void library_game12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game12MouseClicked
        // TODO add your handling code here:
        runGame(3);
    }//GEN-LAST:event_library_game12MouseClicked

    private void library_game11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game11MouseClicked
        // TODO add your handling code here:
        runGame(4);
    }//GEN-LAST:event_library_game11MouseClicked

    private void library_game8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game8MouseClicked
        // TODO add your handling code here:
        runGame(5);
    }//GEN-LAST:event_library_game8MouseClicked

    private void library_game3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game3MouseClicked
        // TODO add your handling code here:
       runGame(6);
    }//GEN-LAST:event_library_game3MouseClicked

    private void library_game10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game10MouseClicked
        // TODO add your handling code here:
        runGame(7);
    }//GEN-LAST:event_library_game10MouseClicked

    private void library_game9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game9MouseClicked
        // TODO add your handling code here:
        runGame(8);
    }//GEN-LAST:event_library_game9MouseClicked

    private void library_game6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game6MouseClicked
        // TODO add your handling code here:
        runGame(9);
    }//GEN-LAST:event_library_game6MouseClicked

    private void library_game7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game7MouseClicked
        // TODO add your handling code here:
        runGame(10);
    }//GEN-LAST:event_library_game7MouseClicked

    private void library_game5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game5MouseClicked
        // TODO add your handling code here:
        runGame(11);
    }//GEN-LAST:event_library_game5MouseClicked

    private void library_game14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game14MouseClicked
        // TODO add your handling code here:
        runGame(12);
    }//GEN-LAST:event_library_game14MouseClicked

    private void library_game13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game13MouseClicked
        // TODO add your handling code here:
        runGame(13);
    }//GEN-LAST:event_library_game13MouseClicked

    private void library_game4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_game4MouseClicked
        // TODO add your handling code here:
        runGame(14);
    }//GEN-LAST:event_library_game4MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        
        int response = JOptionPane.showConfirmDialog(null, "Open browser to download the game?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
        if (response == JOptionPane.NO_OPTION) {
          System.out.println("Cancled download");
        } else if (response == JOptionPane.YES_OPTION) {
          System.out.println("Opening Browser");
          Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("http://46.4.29.144/ipcgames.com/download.php?url_str=https%3A%2F%2F46.4.29.144%2FiGetintopc.com%2Fdownload.php%3Ffilename%3Dipcgames.com_Spec_Ops_The_Line.zip%26expires%3D1639341311%26signature%3D2f132bcc407045a2d3c74a84719ea249&filename=ipcgames.com_Spec_Ops_The_Line.zip"));
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
        } else if (response == JOptionPane.CLOSED_OPTION) {
          System.out.println("JOptionPane closed");
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        
        int response = JOptionPane.showConfirmDialog(null, "Open browser to download the game?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
        if (response == JOptionPane.NO_OPTION) {
          System.out.println("Cancled download");
        } else if (response == JOptionPane.YES_OPTION) {
          System.out.println("Opening Browser");
          Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("http://46.4.29.144/ipcgames.com/download.php?url_str=https%3A%2F%2F46.4.29.144%2FiGetintopc.com%2Fdownload.php%3Ffilename%3Dipcgames.com_Battlefield_V.iso%26expires%3D1639341484%26signature%3D68d1e3e21f99444209fb3b777528b683&filename=ipcgames.com_Battlefield_V.iso\n"));
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
        } else if (response == JOptionPane.CLOSED_OPTION) {
          System.out.println("JOptionPane closed");
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        
        int response = JOptionPane.showConfirmDialog(null, "Open browser to download the game?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE );
        if (response == JOptionPane.NO_OPTION) {
          System.out.println("Cancled download");
        } else if (response == JOptionPane.YES_OPTION) {
          System.out.println("Opening Browser");
          Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("http://95.216.0.40/ipcgames.com/download.php?url_str=https%3A%2F%2F95.216.0.40%2FiGetintopc.com%2Fdownload.php%3Ffilename%3Dipcgames.com_Borderlands_3.iso%26expires%3D1639341612%26signature%3D1ac2d58063ccb9c4373f977eaf8e64e2&filename=ipcgames.com_Borderlands_3.iso"));
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
        } else if (response == JOptionPane.CLOSED_OPTION) {
          System.out.println("JOptionPane closed");
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void store_game1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game1MouseClicked
        // TODO add your handling code here:
        DownloadGame(1);
    }//GEN-LAST:event_store_game1MouseClicked

    private void store_game2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game2MouseClicked
        // TODO add your handling code here:
        DownloadGame(2);
    }//GEN-LAST:event_store_game2MouseClicked

    private void store_game12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game12MouseClicked
        // TODO add your handling code here:
        DownloadGame(3);
    }//GEN-LAST:event_store_game12MouseClicked

    private void store_game8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game8MouseClicked
        // TODO add your handling code here:
        DownloadGame(5);
    }//GEN-LAST:event_store_game8MouseClicked

    private void store_game3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game3MouseClicked
        // TODO add your handling code here:
        DownloadGame(6);
    }//GEN-LAST:event_store_game3MouseClicked

    private void store_game10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game10MouseClicked
        // TODO add your handling code here:
        DownloadGame(7);
    }//GEN-LAST:event_store_game10MouseClicked

    private void store_game9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game9MouseClicked
        // TODO add your handling code here:
        DownloadGame(8);
    }//GEN-LAST:event_store_game9MouseClicked

    private void store_game6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game6MouseClicked
        // TODO add your handling code here:
        DownloadGame(9);
    }//GEN-LAST:event_store_game6MouseClicked

    private void store_game7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game7MouseClicked
        // TODO add your handling code here:
        DownloadGame(10);
    }//GEN-LAST:event_store_game7MouseClicked

    private void store_game5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game5MouseClicked
        // TODO add your handling code here:
        DownloadGame(11);
    }//GEN-LAST:event_store_game5MouseClicked

    private void store_game14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game14MouseClicked
        // TODO add your handling code here:
        DownloadGame(12);
    }//GEN-LAST:event_store_game14MouseClicked

    private void store_game4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game4MouseClicked
        // TODO add your handling code here:
        DownloadGame(14);
    }//GEN-LAST:event_store_game4MouseClicked

    private void user_contactMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_contactMouseClicked
        // TODO add your handling code here:
        System.out.println("Opening Browser");
        Desktop browser = Desktop.getDesktop();
        try {
            browser.browse(new URI("https://mail.google.com/mail/u/0/?fs=1&to=bcsm-s20-045@superior.edu.pk&su=&body=&bcc=bcsm-s20-030@superior.edu.pk&tf=cm&cc=bcsm-f19-384@superior.edu.pk"));
        } catch (Exception e) {
            System.out.println("error : " + e);
        }
    }//GEN-LAST:event_user_contactMouseClicked

    private void user_settingsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_settingsMouseClicked
        // TODO add your handling code here:
        showPanel(panel_Settings);
    }//GEN-LAST:event_user_settingsMouseClicked

    private void changeColors(Color ribonColor, Border mainBorder, Border hoverBorder, Border gameBorder){
//        [255,51,255] // new
//        [140,37,134] // old
        Head.setBackground(ribonColor);
        Main.setBorder(mainBorder);
        Component[] components = panel_VerticalMenu.getComponents();
        
        for (Component component : components) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                       
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setBorder(hoverBorder);
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        if(label.getBorder().equals(select_border))
                           label.setBorder(select_border);
                       else
                           label.setBorder(default_border);
                    }
                });
            }
        }
        
        Component[] componentss = homeGamePanelContainer.getComponents();
        
        for (Component component : componentss) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                       
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                        
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {
                        label.setBorder(gameBorder);
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        if(label.getBorder().equals(select_border))
                           label.setBorder(select_border);
                       else
                           label.setBorder(default_border);
                    }
                });
            }
        }
    }
    
    private void changeFontColor(Color titleColor, Color fontColor){
        lbl_pageTitle.setForeground(titleColor);
        jLabel1.setForeground(fontColor);
        Component[] components = library_recentGamesContainer.getComponents();
        
        for (Component component : components) {
            if (component instanceof JButton) {
                JButton button = (JButton) component;
                button.setForeground(fontColor);
            }
        }
        
        Component[] componentss = store_gameOnSaleContainer.getComponents();
        
        for (Component component : componentss) {
            if (component instanceof JButton) {
                JButton button = (JButton) component;
                button.setForeground(fontColor);
            }
        }
    }
    
    private void changeIconColor(int clrnbr){
        ImageIcon icon[] = new ImageIcon[6];
        icon[0] = new ImageIcon(getClass().getResource("Images/home-4-32 ("+clrnbr+").png"));
        icon[1] = new ImageIcon(getClass().getResource("Images/store-32 ("+clrnbr+").png"));
        icon[2] = new ImageIcon(getClass().getResource("Images/filled-box-32 ("+clrnbr+").png"));
        icon[3] = new ImageIcon(getClass().getResource("Images/newspaper-32 ("+clrnbr+").png"));
        icon[4] = new ImageIcon(getClass().getResource("Images/download-32 ("+clrnbr+").png"));
        icon[5] = new ImageIcon(getClass().getResource("Images/manager-32 ("+clrnbr+").png"));
        
        Image image[] = new Image[6];
        for(int i = 0;i<6;i++){
            image[i] =  icon[i].getImage();
        }
        lbl_homeIcon.setIcon(new ImageIcon(image[0]));
        lbl_storeIcon.setIcon(new ImageIcon(image[1]));
        lbl_libraryIcon.setIcon(new ImageIcon(image[2]));
        lbl_newsIcon.setIcon(new ImageIcon(image[3]));
        lbl_downloadIcon.setIcon(new ImageIcon(image[4]));
        lbl_accountIcon.setIcon(new ImageIcon(image[5]));
    }
    
    private void configuration(Color color, int clrnbr){
        Color ribonColor = color;
        Border mainBorder = BorderFactory.createMatteBorder(0, 2, 2, 2, color);
        Border hoverBorder = BorderFactory.createMatteBorder(0, 0, 1, 0, color);
        Border gameBorder = BorderFactory.createMatteBorder(1, 1, 3, 2, color);
        changeIconColor(clrnbr);
        changeColors(ribonColor, mainBorder, hoverBorder, gameBorder);
        changeFontColor(Color.WHITE, ribonColor);
        addActionToLibraryGameContainer(gameBorder);
        addActionToStoreGameContainer(gameBorder);
        addActionToUserPanel(color);
        panel_user.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, color));
    }
    
    private void jPanel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel5MouseClicked
        // TODO add your handling code here:
        configuration(jPanel5.getBackground(), 1);
    }//GEN-LAST:event_jPanel5MouseClicked

    private void jPanel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel6MouseClicked
        // TODO add your handling code here:
        configuration(jPanel6.getBackground(), 2);
    }//GEN-LAST:event_jPanel6MouseClicked

    private void jPanel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel9MouseClicked
        // TODO add your handling code here:
        configuration(jPanel9.getBackground(), 3);
    }//GEN-LAST:event_jPanel9MouseClicked

    private void jPanel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel8MouseClicked
        // TODO add your handling code here:
        configuration(jPanel8.getBackground(), 4);
    }//GEN-LAST:event_jPanel8MouseClicked

    private void jPanel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel7MouseClicked
        // TODO add your handling code here:
        configuration(jPanel7.getBackground(), 0);
    }//GEN-LAST:event_jPanel7MouseClicked

    private void jPanel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel10MouseClicked
        // TODO add your handling code here:
        configuration(jPanel10.getBackground(), 5);
    }//GEN-LAST:event_jPanel10MouseClicked

    private void jPanel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel11MouseClicked
        // TODO add your handling code here:
        configuration(jPanel11.getBackground(), 6);
    }//GEN-LAST:event_jPanel11MouseClicked

    private void lbl_minimize1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_minimize1MouseClicked
        // TODO add your handling code here:
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_lbl_minimize1MouseClicked

    private void lbl_minimize1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_minimize1MouseEntered
        // TODO add your handling code here:
        Color blue = new Color(107,185,240);
        lbl_minimize1.setForeground(blue);
    }//GEN-LAST:event_lbl_minimize1MouseEntered

    private void lbl_minimize1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_minimize1MouseExited
        // TODO add your handling code here:
        lbl_minimize1.setForeground(Color.white);
    }//GEN-LAST:event_lbl_minimize1MouseExited

    private void checkBox_showPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkBox_showPasswordActionPerformed
        // TODO add your handling code here:
        if(checkBox_showPassword.isSelected())
        {
            txt_password.setEchoChar((char)0);
            txt_confirmPassword.setEchoChar((char)0);
        }
        else
        {
            txt_password.setEchoChar('*');
            txt_confirmPassword.setEchoChar('*');
        }
    }//GEN-LAST:event_checkBox_showPasswordActionPerformed

    private void txt_emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusLost
        // TODO add your handling code here:
        Pattern p = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+com)$");
        if(!txt_email.getText().equals(""))
        {
            Matcher m = p.matcher(txt_email.getText());
            if(m.find())
                lbl_emailValidation.setText("");
            else
            {
                lbl_emailValidation.setText("Invalid Email, must include '@domain.com'");
                lbl_emailValidation.setForeground(Color.red);
            }
        }
    }//GEN-LAST:event_txt_emailFocusLost

    private void user_profileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_profileMouseClicked
          // TODO add your handling code here:
        showPanel(panel_Profile);
            try {
                Connection con = Database.connect();
                Statement statement = con.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT * FROM RegistrationInfo WHERE userName = '"+userName+"'");
                while(resultSet.next())
                {
                    txt_name.setText(resultSet.getString("fullName"));
                    txt_userName.setText(resultSet.getString("userName"));
                    txt_email.setText(resultSet.getString("email"));
                    txt_password.setText(resultSet.getString("userPassword"));
                    txt_confirmPassword.setText("");
                    txt_id.setText(resultSet.getString("userID"));
                }
                con.close();
            } 
            catch (Exception e)
            {
                System.err.println(e);
            }
    }//GEN-LAST:event_user_profileMouseClicked

    private void btn_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_editActionPerformed
        // TODO add your handling code here:
        disableProfileFields(true);
        btn_save.setEnabled(true);
    }//GEN-LAST:event_btn_editActionPerformed

    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_saveActionPerformed
        // TODO add your handling code here:
        if(txt_name.getText().equals("") || txt_email.getText().equals("") || txt_userName.getText().equals("") || txt_password.getText().equals("") || txt_confirmPassword.getText().equals("")
                || txt_id.getText().equals(""))
        {
                JOptionPane.showMessageDialog(null, "Empty Field(s)");
        }
        else
        {
            try {
                if (lbl_userValidation.getText().equals("Username already exists")) {
                    JOptionPane.showMessageDialog(null, "Change Username");
                }
                else{
                    Connection con = Database.connect();
                    Statement statement = con.createStatement();
                    statement.executeUpdate("UPDATE RegistrationInfo SET fullName = '"+txt_name.getText()+"',userName = '"+txt_userName.getText()+"',"
                            + "email = '"+txt_email.getText()+"', userPassword = '"+txt_password.getText()+"',confirmPassword = '"+txt_confirmPassword.getText()+"' WHERE userID = '"+txt_id.getText()+"'");
                    txt_confirmPassword.setText("");
                    checkBox_showPassword.setSelected(false);
                    JOptionPane.showMessageDialog(null, "Data Saved!");
                    btn_save.setEnabled(false);
                    con.close();
                }
                } 
                catch (Exception e)
                {
                    System.err.println(e);
                }
            disableProfileFields(false);
        }
    }//GEN-LAST:event_btn_saveActionPerformed

    private void txt_confirmPasswordFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_confirmPasswordFocusLost
        // TODO add your handling code here:
        if(!txt_confirmPassword.getText().equals(txt_password.getText()))
        {
            lbl_conPassValidation.setText("Password Does not Match!");
            lbl_conPassValidation.setForeground(Color.red);
        }
        else
        {
            lbl_conPassValidation.setText("");
        }
    }//GEN-LAST:event_txt_confirmPasswordFocusLost

    private void txt_passwordFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_passwordFocusLost
        // TODO add your handling code here:
        if(!txt_confirmPassword.getText().equals(txt_password.getText()))
        {
            lbl_conPassValidation.setText("Password Does not Match!");
            lbl_conPassValidation.setForeground(Color.red);
        }
        else
        {
            lbl_conPassValidation.setText("");
        }
    }//GEN-LAST:event_txt_passwordFocusLost

    private void txt_userNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_userNameFocusLost
        // TODO add your handling code here:
        try {
                Connection con = Database.connect();
                Statement statement = con.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT * FROM RegistrationInfo WHERE userName = '"+txt_userName.getText()+"'");
                while(resultSet.next())
                {
                    lbl_userValidation.setText("username already exists");
                    lbl_userValidation.setForeground(Color.red);
                }
                con.close();
            } 
            catch (Exception e)
            {
                System.err.println(e);
            }
    }//GEN-LAST:event_txt_userNameFocusLost

    private void txt_userNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_userNameFocusGained
        // TODO add your handling code here:
        lbl_userValidation.setText("");
    }//GEN-LAST:event_txt_userNameFocusGained

    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://techcrunch.com/2021/06/14/e3-2021-catch-up/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel17MouseClicked

    private void jLabel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel18MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://techcrunch.com/2021/06/14/e3-2021-catch-up/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel18MouseClicked

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://techcrunch.com/2021/06/14/e3-2021-catch-up/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://techcrunch.com/2021/06/14/e3-2021-catch-up/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://techcrunch.com/2021/06/14/e3-2021-catch-up/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel15MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://www.theverge.com/games"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://www.gamespot.com/news/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://www.pcgamer.com/news/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel13MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://www.ign.com/?filter=games"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://techcrunch.com/2021/06/14/e3-2021-catch-up/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel21MouseClicked

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://techcrunch.com/2021/06/14/e3-2021-catch-up/"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel20MouseClicked

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
        // TODO add your handling code here:
        Desktop browser = Desktop.getDesktop();
            try {
                browser.browse(new URI("https://www.ign.com/articles/e3-2021-schedule-date-events-games-news"));
                System.out.println("Opening browser");
            } catch (Exception e) {
                System.out.println("error : " + e);
            }
    }//GEN-LAST:event_jLabel22MouseClicked

    private void store_game11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game11MouseClicked
        // TODO add your handling code here:
        DownloadGame(4);
    }//GEN-LAST:event_store_game11MouseClicked

    private void store_game13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_store_game13MouseClicked
        // TODO add your handling code here:
        DownloadGame(13);
    }//GEN-LAST:event_store_game13MouseClicked

    private void disableProfileFields(Boolean ans){
        txt_name.setEnabled(ans);
        txt_userName.setEnabled(ans);
        txt_email.setEnabled(ans);
        txt_password.setEnabled(ans);
        txt_confirmPassword.setEnabled(ans);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePage().setVisible(true);
            }
        });
    }
    
//    try {
//            Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + "I:\\cuphead\\Cuphead.exe");
//        } catch (IOException e) {
//            System.err.println("invalid username\nexception: "+e);
//        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Head;
    private javax.swing.JPanel Main;
    private javax.swing.JButton btn_edit;
    private javax.swing.JLabel btn_next;
    private javax.swing.JLabel btn_previous;
    private javax.swing.JButton btn_save;
    private javax.swing.JCheckBox checkBox_showPassword;
    private javax.swing.JLabel gameOnSale1;
    private javax.swing.JLabel gameOnSale2;
    private javax.swing.JLabel gameOnSale3;
    private javax.swing.JLabel gameOnSale4;
    private javax.swing.JLabel gameOnSale5;
    private javax.swing.JLabel gameOnSale6;
    private javax.swing.JPanel homeGamePanelContainer;
    private javax.swing.JLabel home_gamePanel1;
    private javax.swing.JLabel home_gamePanel2;
    private javax.swing.JLabel home_gamePanel3;
    private javax.swing.JLabel home_gamePanel4;
    private javax.swing.JLabel home_gamePanel5;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lbl_accountIcon;
    private javax.swing.JLabel lbl_close;
    private javax.swing.JLabel lbl_conPassValidation;
    private javax.swing.JLabel lbl_downloadIcon;
    private javax.swing.JLabel lbl_emailValidation;
    private javax.swing.JLabel lbl_homeIcon;
    private javax.swing.JLabel lbl_libraryIcon;
    private javax.swing.JLabel lbl_minimize1;
    private javax.swing.JLabel lbl_newsIcon;
    private javax.swing.JLabel lbl_pageTitle;
    private javax.swing.JLabel lbl_storeIcon;
    private javax.swing.JLabel lbl_userValidation;
    private javax.swing.JPanel library_allGamesContainer;
    private javax.swing.JLabel library_game1;
    private javax.swing.JLabel library_game10;
    private javax.swing.JLabel library_game11;
    private javax.swing.JLabel library_game12;
    private javax.swing.JLabel library_game13;
    private javax.swing.JLabel library_game14;
    private javax.swing.JLabel library_game2;
    private javax.swing.JLabel library_game3;
    private javax.swing.JLabel library_game4;
    private javax.swing.JLabel library_game5;
    private javax.swing.JLabel library_game6;
    private javax.swing.JLabel library_game7;
    private javax.swing.JLabel library_game8;
    private javax.swing.JLabel library_game9;
    private javax.swing.JPanel library_recentGamesContainer;
    private javax.swing.JPanel panel_Home;
    private javax.swing.JPanel panel_Library;
    private javax.swing.JPanel panel_News;
    private javax.swing.JPanel panel_Profile;
    private javax.swing.JPanel panel_Settings;
    private javax.swing.JPanel panel_Store;
    private javax.swing.JPanel panel_VerticalMenu;
    private javax.swing.JPanel panel_imageSlider;
    private javax.swing.JPanel panel_latestNews;
    private javax.swing.JPanel panel_oldNews;
    private javax.swing.JPanel panel_user;
    private javax.swing.JLabel recentGame1;
    private javax.swing.JLabel recentGame2;
    private javax.swing.JLabel recentGame3;
    private javax.swing.JLabel recentGame4;
    private javax.swing.JLabel recentGame5;
    private javax.swing.JLabel recentGame6;
    private javax.swing.JLabel sliderImage;
    private javax.swing.JLabel store_game1;
    private javax.swing.JLabel store_game10;
    private javax.swing.JLabel store_game11;
    private javax.swing.JLabel store_game12;
    private javax.swing.JLabel store_game13;
    private javax.swing.JLabel store_game14;
    private javax.swing.JLabel store_game2;
    private javax.swing.JLabel store_game3;
    private javax.swing.JLabel store_game4;
    private javax.swing.JLabel store_game5;
    private javax.swing.JLabel store_game6;
    private javax.swing.JLabel store_game7;
    private javax.swing.JLabel store_game8;
    private javax.swing.JLabel store_game9;
    private javax.swing.JPanel store_gameOnSaleContainer;
    private javax.swing.JPanel store_gamesContainer;
    private javax.swing.JPasswordField txt_confirmPassword;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_id;
    private javax.swing.JTextField txt_name;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_userName;
    private javax.swing.JLabel user_contact;
    private javax.swing.JLabel user_logout;
    private javax.swing.JLabel user_profile;
    private javax.swing.JLabel user_settings;
    // End of variables declaration//GEN-END:variables
}
